const APP = 'app-coran-v6';
const AUDIO = 'audio-coran-v1';
const FICHIERS = ['./', 'config.js', 'sourates.js', 'manifest.json', 'icon-192.png', 'icon-512.png'];

// Met les fichiers de l'application en cache (en nettoyant les réponses "redirigées",
// que Chrome refuse de servir pour une navigation).
self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(APP);
    for (const f of FICHIERS) {
      const r = await fetch(f, { cache: 'reload' });
      if (!r.ok) throw new Error('Échec : ' + f);
      const propre = r.redirected
        ? new Response(await r.blob(), { status: 200, headers: r.headers })
        : r;
      await c.put(f, propre);
    }
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(
    ks.filter(k => k !== APP && k !== AUDIO).map(k => caches.delete(k))
  )).then(() => self.clients.claim()));
});

// Réponse partielle (Range) à partir d'un fichier audio déjà téléchargé
async function reponseRange(req, cached) {
  const buf = await cached.arrayBuffer();
  const m = /bytes=(\d*)-(\d*)/.exec(req.headers.get('range') || '');
  if (!m) return cached;
  const total = buf.byteLength;
  const debut = m[1] ? parseInt(m[1], 10) : 0;
  const fin = m[2] ? Math.min(parseInt(m[2], 10), total - 1) : total - 1;
  return new Response(buf.slice(debut, fin + 1), {
    status: 206,
    headers: {
      'Content-Type': cached.headers.get('Content-Type') || 'audio/mpeg',
      'Content-Range': `bytes ${debut}-${fin}/${total}`,
      'Content-Length': String(fin - debut + 1),
      'Accept-Ranges': 'bytes'
    }
  });
}

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // Toute ouverture de l'application (/, /index.html, application installée…)
  // reçoit la page d'accueil en cache, ou le réseau à défaut.
  if (req.mode === 'navigate' && url.origin === self.location.origin) {
    e.respondWith(caches.match('./').then(r => r || fetch(req)));
    return;
  }

  if (/\/\d{3}\.mp3$/.test(url.pathname)) {
    e.respondWith((async () => {
      const c = await caches.open(AUDIO);
      const cached = await c.match(req.url);
      if (cached) return req.headers.get('range') ? reponseRange(req, cached) : cached;
      return fetch(req);
    })());
    return;
  }

  e.respondWith(caches.match(req).then(r => r || fetch(req)));
});
