// ============================================================
// CONFIGURATION : adresse où se trouvent tes 114 fichiers audio
// ============================================================
// Pendant les tests (audios dans le dossier "audio" à côté de l'appli) :
//   const AUDIO_BASE = 'audio/';
// Une fois les audios sur Cloudflare R2, remplace par l'adresse publique
// de ton stockage, TOUJOURS avec une barre oblique finale, par exemple :
//   const AUDIO_BASE = 'https://pub-xxxxxxxx.r2.dev/';
const AUDIO_BASE = 'https://pub-18ab523cd4aa4b4881d90e18de3aea82.r2.dev/';

// Mis à true uniquement pour la version "tout-en-un" (audios inclus dans l'application)
const EMBARQUE = false;
